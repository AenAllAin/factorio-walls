-- Iron Cable
data:extend (
{
  {
    type = "fish",
    name = "iron-cable",
    icon = "__base__/graphics/icons/copper-cable.png",
    flags = {"player-creation"},
    max_health = 1,
    pictures =
    {
        filename = "__base__/graphics/icons/copper-cable.png",
        width = 32,
        height = 40
    }
  },

}
)
