require("prototypes.entity.entities")

require("prototypes.item.item")

require("prototypes.recipe.recipe")

require("prototypes.technology.technology")
